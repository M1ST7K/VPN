const fs=require('fs'),path=require('path'),crypto=require('crypto'),sharp=require('sharp');
const root=path.resolve(__dirname,'..');
async function main(){
 const m=JSON.parse(fs.readFileSync(path.join(root,'manifest/assets.json'))),screens=JSON.parse(fs.readFileSync(path.join(root,'manifest/screens.json')));
 const ids=new Set(),files=new Set(),errors=[];let transparent=0,opaque=0;
 for(const a of m.assets){if(ids.has(a.id))errors.push('duplicate id '+a.id);ids.add(a.id);
  if(!/^hf_[a-z0-9_]+$/.test(a.id))errors.push('invalid Android name '+a.id);
  for(const v of a.variants){if(files.has(v.file))errors.push('duplicate file '+v.file);files.add(v.file);
   const b=fs.readFileSync(path.join(root,v.file));const meta=await sharp(b).metadata();const stats=await sharp(b).stats();
   if(crypto.createHash('sha256').update(b).digest('hex')!==v.sha256)errors.push('hash '+v.file);
   if(meta.width!==v.width||meta.height!==v.height)errors.push('dimensions '+v.file);
   if(meta.format!=='png')errors.push('format '+v.file);
   if(a.category!=='artwork'){
    if(!meta.hasAlpha)errors.push('no alpha '+v.file);
    else if(['icons','flags','navigation','illustrations','brand','controls'].includes(a.category)&&stats.channels[3].min===255)errors.push('no alpha coverage below 255 '+v.file);
    if(meta.hasAlpha)transparent++;
   }else{if(meta.hasAlpha)transparent++;else opaque++;}
   if(a.logical_size_dp){const factor=m.density_scales[v.density];if(v.width!==a.logical_size_dp[0]*factor||v.height!==a.logical_size_dp[1]*factor)errors.push('density mismatch '+v.file);}
  }
 }
 function walk(x){if(typeof x==='string'&&/^hf_[a-z0-9_]+$/.test(x)&&!ids.has(x))errors.push('unresolved asset '+x);else if(Array.isArray(x))x.forEach(walk);else if(x&&typeof x==='object')Object.values(x).forEach(walk);}
 walk(screens);walk(JSON.parse(fs.readFileSync(path.join(root,'manifest/components.json'))));
 if(screens.screens.length!==18)errors.push('screen count');
 for(const s of screens.screens)if(!fs.existsSync(path.join(root,'references',s.reference)))errors.push('missing reference '+s.reference);
 if(new Set(screens.screens.map(s=>s.id)).size!==18)errors.push('duplicate screen');
 const lock=JSON.parse(fs.readFileSync(path.join(root,'docs/HOTFOX_REFERENCE_LOCK.json')));
 for(const s of lock.screens){const b=fs.readFileSync(path.join(root,'references',path.basename(s.path)));if(crypto.createHash('sha256').update(b).digest('hex')!==s.sha256)errors.push('modified reference '+s.path);}
 for(const file of fs.readdirSync(path.join(root,'android/res/drawable'))){const xml=fs.readFileSync(path.join(root,'android/res/drawable',file),'utf8');for(const match of xml.matchAll(/@drawable\/([a-z0-9_]+)/g))if(!ids.has(match[1]))errors.push('unresolved Android drawable '+match[1]);}
 const report={schema:1,result:errors.length?'FAIL':'PASS',unique_assets:ids.size,png_files:files.size,png_with_alpha:transparent,opaque_artwork:opaque,screens:screens.screens.length,checks:['unique IDs','Android resource names','PNG decode','SHA-256','dimensions/densities','actual alpha channel','alpha coverage below 255 in isolated UI elements, including antialiased tiny caps','18-screen reference original hashes','screen asset links resolve','Android XML drawable links resolve'],not_verified:['pixel equality to original boards','Android resource compilation/APK build','18 rendered app screens','TalkBack/interaction/device VPN E2E'],errors};
 fs.mkdirSync(path.join(root,'qa'),{recursive:true});fs.writeFileSync(path.join(root,'qa/asset_validation.json'),JSON.stringify(report,null,2)+'\n');console.log(JSON.stringify(report,null,2));if(errors.length)process.exit(1);
}
main().catch(e=>{console.error(e);process.exit(1)});
