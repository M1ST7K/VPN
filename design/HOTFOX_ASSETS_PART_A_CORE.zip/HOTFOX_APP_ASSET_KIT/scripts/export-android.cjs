/* Export to a new directory; never silently overwrite application resources. */
const fs=require('fs'),path=require('path');
const root=path.resolve(__dirname,'..');
const target=process.argv[2]&&path.resolve(process.argv[2]);
if(!target){console.error('Usage: node scripts/export-android.cjs /absolute/new-output-dir');process.exit(2)}
if(fs.existsSync(target)){console.error('Destination already exists. Choose a new export directory; nothing was changed.');process.exit(2)}
const manifest=JSON.parse(fs.readFileSync(path.join(root,'manifest/assets.json')));
const entries=manifest.assets.filter(a=>a.category!=='fixture_apps');
for(const a of entries)for(const v of a.variants){
 const dir=path.join(target,'res','drawable-'+v.density);fs.mkdirSync(dir,{recursive:true});
 fs.copyFileSync(path.join(root,v.file),path.join(dir,a.id+'.png'));
}
fs.cpSync(path.join(root,'android/res'),path.join(target,'res'),{recursive:true,errorOnExist:true,force:false});
console.log(JSON.stringify({export:target,assets:entries.length,fixture_icons_excluded:true,next:'Review then copy res into actual app/src/main/res. Bind current native views/callbacks. No app source was edited.'},null,2));
