# Подключение к Android

Из корня распакованного комплекта:

```sh
node scripts/export-android.cjs /absolute/path/to/new-hotfox-export
```

Node нужен только для экспорта, зависимости не нужны. Выходная папка должна отсутствовать: скрипт откажется перезаписывать существующую. Он создаст `res/drawable-mdpi`, `drawable-xhdpi`, `drawable-xxhdpi`, `drawable-xxxhdpi`, `drawable-nodpi`, XML drawables и цвета. Иконки `fixture_apps` и исходные boards в production export не попадут.

Скопируйте после review нужные ресурсы в существующий `app/src/main/res` bootstrap overlay. Ресурсы имеют префикс `hf_`, чтобы снизить риск коллизий. Если имя уже существует, сравните и согласуйте изменение; не перезаписывайте чужую работу автоматически.

## Применение

- Иконка: `@drawable/hf_shield_cream`, размер 24dp, минимум 48dp touch target у родительского действия. PNG без автоматического tint.
- Кнопка: `hf_native_primary` или `hf_native_secondary` как background существующего Button; нативная строка и текущий listener. Уберите только визуальные default tint/insets/elevation, если они портят соответствие; сохраните focus/ripple/accessibility. XML — стартовые shapes, градиент уточняется по фактическому Android render.
- Поле: `hf_native_input` у существующего EditText; не менять parser/validation/IME/callbacks. Фокус уже задан, error-состояние реализуется нативно с реальным текстом ошибки.
- Checkbox: `hf_native_checkbox` у нативного CompoundButton/CheckBox; не добавлять вторую галочку и не рисовать отдельную штатную кнопку поверх PNG. Сохранить checked/disabled/contentDescription.
- Switch: `hf_native_switch_orange`/`hf_native_switch_green` — полное изображение track+thumb. Можно использовать у нативного ToggleButton/CompoundButton с пустыми visual textOn/textOff, отдельным видимым label и accessibility label. Не ставить это одновременно в thumb и track обычного Switch, иначе получится двойной переключатель. Привязка только к существующему persisted состоянию.
- Карточка: `hf_native_card`, реальные строки и divider. Фиксированный `hf_surface_group.png` не растягивать с деформацией углов.
- Лиса: `@drawable/hf_fox_planet` или `@drawable/hf_fox_bust`, decorative ImageView, `fitCenter`, без перехвата touch. Opaque фон намеренный. Не ставить full-screen иллюстрацию поверх нативного UI.
- Орбиты/щит/check: прозрачные независимые ImageView, слои в `screens.json`. У decorative views `importantForAccessibility=no`.
- Список приложений: production icons через текущий PackageManager/provider. Fixture logos не включаются в экспорт намеренно.

PNG не создают callback и не обеспечивают VPN-защиту: существующая архитектура остаётся владельцем состояния. Этот комплект не вводит новые Activity, service, permission, библиотеку или сетевой код. Compose-миграция или замена архитектуры ради дизайна не нужны.

Для пересборки PNG из SVG-геометрии нужны Node + `sharp`:

```sh
node scripts/build-kit.cjs
node scripts/build-screen-map.cjs
node scripts/verify-kit.cjs
```

Две исходные PNG лисы уже входят в комплект; скрипт не вызывает генерацию повторно и не режет референсы. Техническая проверка PNG не заменяет Android resource compile или проверку реальных экранов.
