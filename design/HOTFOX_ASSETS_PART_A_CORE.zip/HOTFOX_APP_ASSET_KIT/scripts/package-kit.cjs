/* A ZIP is created by the system zip command after validation. */
const fs=require('fs'),path=require('path'),crypto=require('crypto');
const root=path.resolve(__dirname,'..');
const files=[];
function visit(dir){for(const e of fs.readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){const p=path.join(dir,e.name);if(e.isDirectory())visit(p);else if(path.relative(root,p)!=='manifest/SHA256SUMS.txt')files.push(p);}}
visit(root);fs.writeFileSync(path.join(root,'manifest/SHA256SUMS.txt'),files.map(p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex')+'  '+path.relative(root,p)).join('\n')+'\n');
console.log('Checksummed '+files.length+' files');
